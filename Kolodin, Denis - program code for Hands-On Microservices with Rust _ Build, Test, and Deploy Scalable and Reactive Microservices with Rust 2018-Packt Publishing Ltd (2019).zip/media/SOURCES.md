`image.jpg` - https://www.pexels.com/photo/abandoned-abstract-close-up-corrosion-1301413/
