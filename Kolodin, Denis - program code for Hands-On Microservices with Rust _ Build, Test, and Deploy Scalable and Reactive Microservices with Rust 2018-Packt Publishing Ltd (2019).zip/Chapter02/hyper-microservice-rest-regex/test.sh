curl -X POST http://localhost:8080/user/
curl -X POST http://localhost:8080/user/
curl -X POST http://localhost:8080/user/
curl -X DELETE http://localhost:8080/user/1
curl http://localhost:8080/users
