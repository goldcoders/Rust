docker build -t rust-slave .
