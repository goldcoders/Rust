DROP TABLE users;

DROP TABLE comments;
