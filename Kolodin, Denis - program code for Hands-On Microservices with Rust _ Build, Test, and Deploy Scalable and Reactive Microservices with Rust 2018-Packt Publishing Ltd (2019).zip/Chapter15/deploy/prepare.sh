docker build -t rust:nightly nightly
