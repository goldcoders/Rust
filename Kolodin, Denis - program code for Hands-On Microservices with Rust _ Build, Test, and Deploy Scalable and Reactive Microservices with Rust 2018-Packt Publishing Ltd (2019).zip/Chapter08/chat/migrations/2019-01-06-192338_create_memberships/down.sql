DROP TABLE memberships;
