DROP TABLE messages;
