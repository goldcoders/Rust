DROP TABLE channels;
