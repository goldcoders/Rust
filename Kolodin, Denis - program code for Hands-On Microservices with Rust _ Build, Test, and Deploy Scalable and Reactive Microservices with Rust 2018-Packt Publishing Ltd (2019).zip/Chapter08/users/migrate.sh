DATABASE_URL=test.db diesel migration run
