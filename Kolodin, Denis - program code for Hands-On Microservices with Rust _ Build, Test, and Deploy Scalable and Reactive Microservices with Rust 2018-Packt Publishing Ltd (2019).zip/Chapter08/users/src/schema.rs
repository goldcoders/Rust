table! {
    users (id) {
        id -> Text,
        name -> Text,
        email -> Text,
    }
}
