DROP TABLE comments;
