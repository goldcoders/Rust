table! {
    users (id) {
        id -> Text,
        email -> Text,
        password -> Text,
    }
}
