docker run -it --rm --name test-redis -p 6379:6379 redis
