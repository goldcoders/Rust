docker run -it --rm --name test-mongo -p 27017:27017 mongo
