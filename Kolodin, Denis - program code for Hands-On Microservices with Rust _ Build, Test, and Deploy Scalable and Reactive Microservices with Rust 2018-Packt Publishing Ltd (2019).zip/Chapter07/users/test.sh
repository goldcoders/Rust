docker run -it --rm --name test-pg -p 5432:5432 postgres
