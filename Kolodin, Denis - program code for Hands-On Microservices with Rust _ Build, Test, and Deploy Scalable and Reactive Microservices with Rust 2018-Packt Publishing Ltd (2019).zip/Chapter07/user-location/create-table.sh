aws dynamodb create-table --cli-input-json file://table.json --endpoint-url http://localhost:8000 --region custom
