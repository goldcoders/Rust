docker run -it --rm --name test-rabbit -p 5672:5672 rabbitmq:3
