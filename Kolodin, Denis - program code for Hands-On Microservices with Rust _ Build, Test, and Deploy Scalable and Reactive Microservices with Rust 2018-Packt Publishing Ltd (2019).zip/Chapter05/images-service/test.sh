curl --request POST \
     --data-binary "@../../media/image.jpg" \
     "http://localhost:8080/upload"
