DROP TABLE comments
