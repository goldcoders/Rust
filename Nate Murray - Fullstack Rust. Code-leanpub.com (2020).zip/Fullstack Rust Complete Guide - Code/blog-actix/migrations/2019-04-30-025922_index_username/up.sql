CREATE UNIQUE INDEX username_unique_idx ON users (username)
