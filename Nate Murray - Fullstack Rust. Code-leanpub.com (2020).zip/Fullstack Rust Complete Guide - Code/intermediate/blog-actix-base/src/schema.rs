table! {
    users (id) {
        id -> Integer,
        username -> Text,
    }
}
