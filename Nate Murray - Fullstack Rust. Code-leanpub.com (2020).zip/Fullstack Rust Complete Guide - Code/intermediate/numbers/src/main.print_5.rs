fn main() {
    numbers::print();
}
