import * as wasm from "hello-bindgen";

let result = wasm.greet("Rust");
console.log(result);
