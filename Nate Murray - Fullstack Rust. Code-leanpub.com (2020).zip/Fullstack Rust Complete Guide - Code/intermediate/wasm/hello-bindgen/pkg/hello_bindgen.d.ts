/* tslint:disable */
/**
* @param {string} name 
* @returns {string} 
*/
export function greet(name: string): string;
