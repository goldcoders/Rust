fn main() {
    numbers::print(5);
}
