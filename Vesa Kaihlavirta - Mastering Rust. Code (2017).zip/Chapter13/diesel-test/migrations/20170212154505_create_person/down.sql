DROP TABLE person
