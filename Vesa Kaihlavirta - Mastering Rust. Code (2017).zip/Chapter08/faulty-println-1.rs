fn main() {
    println!("I have two parameters {} {}, but am only supplied one", 1);
}
