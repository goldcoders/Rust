#![feature(plugin)]
#![plugin(simplest_compiler_plugin)]

fn main() {
    hello!();
}
