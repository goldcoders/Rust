#[macro_use]
extern crate macro11crate;

#[derive(Foobar)]
struct Foo;

fn main() {
    
}
