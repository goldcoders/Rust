use std::ascii::AsciiExt;

fn main() {
    let lower_case_a = 'a';
    let upper_case_a = lower_case_a.to_ascii_uppercase();

    println!("{} upper cased is {}", lower_case_a, upper_case_a);
}
