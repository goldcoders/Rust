The book will appeal to application developers who would like to build concurrent applications with Rust. Basic knowledge of Rust is assumed but not absolutely required.

To really dive into the content of this book, you should write out the example code and solve the exercises. For that, you�ll need a fairly recent computer: 1 GB of RAM should be enough for the purposes of this book, but the more you have the faster the builds will be.

Linux is the best-supported operating system here, but Rust itself is also a first-class citizen on macOS and recent versions of Windows, so all the examples should adapt well there.

Note: There are no code files for Chapter 15.